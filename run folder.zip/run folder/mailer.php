<?php
 header('Access-Control-Allow-Origin: *');  
 mail("5163200517@vtext.com", "I need help!", "I'm uncomfortable, make an excuse to call me and get me out of this situation!!");
?>