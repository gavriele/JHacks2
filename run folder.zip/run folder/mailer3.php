<?php
header('Access-Control-Allow-Origin: *'); 
mail("4107946414@vtext.com", "I need help!", "Call 911 Now!!");
?>