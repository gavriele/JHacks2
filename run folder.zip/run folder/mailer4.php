<?php
header('Access-Control-Allow-Origin: *'); 
mail("7326751654@vtext.com", "I need help!", "I am in an abusive situation and I need help. Send someone now!!");
?>