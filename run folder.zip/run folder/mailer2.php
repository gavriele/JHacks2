<?php
header('Access-Control-Allow-Origin: *'); 
mail("2406028204@text.republicwireless.com", "Suspicious activity!", "There is suspcious activity near me, I can't call, call the police!");
?>